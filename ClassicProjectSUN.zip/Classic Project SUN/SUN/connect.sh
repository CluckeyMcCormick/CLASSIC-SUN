echo "password is: 9AVseAwDl4RzCHDs3hS_-fz6Yl" 
psql -h ec2-54-204-7-145.compute-1.amazonaws.com -p 5432 -U cqdweicgxchvez demgp20hpcaetd